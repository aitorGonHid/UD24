# SPring_P05_CRUD_H2
Spring Project with JPA + H2 (Simple CRUD) only one Entity.
